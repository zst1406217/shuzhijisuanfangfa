%% problem1
clc,clear
cond(hilb(2))
cond(hilb(6))
cond(hilb(10))